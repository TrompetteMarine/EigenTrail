# EigenTrail

Rust sources for the EigenTrail R package. See https://github.com/TrompetteMarine/EigenTrail for installation and usage.
